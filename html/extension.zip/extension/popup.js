console.log("WTF1");

document.getElementById("replaceText").addEventListener("click", function () {
    console.log("wtf");
});
